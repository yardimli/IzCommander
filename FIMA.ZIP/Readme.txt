
I have been using Delphi for several years in writing software for clients and have developed some routines that I have found useful in many of these applications. The applications are mostly databases in which the user did not want all the restrictions imposed by the usual off-the-shelf programs. I have recently retired and decided to turn some of the routines into Delphi components and they are the ones included here -- The FIMA (FIle MAnager) routines. In addition to the components themselves, there is a help file, a 'Create Wizard' that will create various kinds of empty files that represent the early stages of a database system, a program to test the appearance of the SelKey component, a utility program to compress vfiles and a sample application. All of these were written for Delphi 3.

All the source files are included. You may distribute these files as long as you distribute the packet as a whole and do not edit any of the files. You may use the components in anyway you wish for your own personal use. However there are two restrictions.

1.  If you incorporate these components into any software that you sell for profit then you should send me at least $25.  If you make a lot of money send me more.

2. If you improve any of these components or if you derive new components from them I would like to have a courtesy copy (source included) of your new or improved component. I promise to NEVER release any source code you send to me in honoring this obligation. I am especially interested in improvements to the SelKey component.

Apart from these restrictions the software is freeware.

As usual I release this software with no guarantee of its correctness or suitability for any proposed purpose. I am not responsible for any damages you may suffer either directly or indirectly by using this software. While the software is free I will cheerfully accept gifts in any amount.

Gifts (or snail mail) can be sent to

Len Bruening
5246 NW 164th Ave.
Portland, OR  97229-8912

e-mail:  lenbat@teleport.com

My fax machine is not always on, but when it is the number is (503) 690-7130.

Installation instructions.

The packet is all contained in zip files. In general each of the zip files has a 'readme.txt' file that contains instruction pecular to that zip file. Unzip the readme.txt file for each zip file and follow instruction there. Here are the contents of the various zip files.

FimaPas.zip:  This file contains the actual components in .pas, .res, and .dfm files. Unzip these to the directory where you put 3rd party components, run Delphi, select Components/Install, browse to the 'Allreg.pas' file and compile. The five components will appear on a tab called 'Len's'.

FimaHelp.zip: This is a standard help file that you can incorporate in Delphi's help. Unzip them to the Delphi\Help directory and, using the Help Workshop that comes with Windows 95, add the line 'Include Fima.Hlp' in the Delphi3.cnt file. You should be able to press F1 on a component in the IDE and bring up help for that component.

FimaUtil.zip.  This file contains three utility programs. 
  CreateP creates empty data files that are used in data base applications.
  Compress squeezes any unused space out of a file with variable length records, something like the defragmenter does.
  TestKey allows you to see how the SelKey component works as seen by the user.
All of these are in source form and need to be compiled.

Books.zip.  This file unzips to a sample application that uses the FIMA components. To save space, only the source code is included and this must be compiled for the demo program to work.

